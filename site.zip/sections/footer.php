<footer class="footer bg-dark text-white text-center py-4">
    <div>
        <a href="https://www.facebook.com" class="text-white mx-2"><i class="bi bi-facebook"></i></a>
        <a href="https://telegram.org" class="text-white mx-2"><i class="bi bi-telegram"></i></a>
        <a href="viber://chat?number=%2B380509586722" class="text-white mx-2"><i class="bi bi-viber"></i></a>
    </div>
    <p class="mt-3 fs-5">З усіма питаннями звертайтеся до оргкомітету «ПРОСТІР ТАЛАНТІВ» через Viber, ТГ, або телефонуйте: +38 (050) 958-67-22</p>
    <p class="fs-5">📧 Електронна пошта: <a href="mailto:Artprostir@gmail.com" class="text-decoration-none text-white">Artprostir@gmail.com</a></p>
    <p class="mb-3 fs-5">© 2024 Гармонія Мистецтва. Всі права захищені.</p>
</footer>
