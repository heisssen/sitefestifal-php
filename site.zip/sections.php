<?php
$sections = [
    ['name' => 'hero', 'path' => 'sections/hero.php'],
    ['name' => 'about', 'path' => 'sections/about.php'],
    ['name' => 'goals', 'path' => 'sections/goals.php'],
    ['name' => 'nominations', 'path' => 'sections/nominations.php'],
    ['name' => 'age-categories', 'path' => 'sections/age-categories.php'],
    ['name' => 'participation', 'path' => 'sections/participation.php'],
    ['name' => 'awards', 'path' => 'sections/awards.php'],
    ['name' => 'footer', 'path' => 'sections/footer.php'],
];
?>
